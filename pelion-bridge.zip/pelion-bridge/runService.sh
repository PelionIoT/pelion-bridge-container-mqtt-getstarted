#!/bin/sh

rm -f ./logs/*.log 2> /dev/null
mkdir -p ./logs
cd ${HOME}/service/target
java -Dconfig_file="../conf/service.properties" -jar pelion-bridge-1.0.war 2>&1 1> ../logs/pelion-bridge.log
